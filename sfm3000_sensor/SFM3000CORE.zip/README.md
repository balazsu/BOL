/*
  Library for reading values from flowmeter Sensirion SFM3000
  Released into the public domain.
*/

## Installation
Download SFM3000CORE > 14CORE > 
Copy the SFM3000CORE.c / SFM3000CORE.h to your Arduino/Libraries directory then restart your Arduino IDE

## Integrating it into your sketch
Copy the source code from 14core.com and phase to your Arduino IDE.
## Find example code in folder "examples"

More code diagram and schematics > 
http://www.14core.com
